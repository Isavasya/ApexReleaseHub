#include <stdio.h>

int main(void) {
    int A_int = 98;

    printf("Correct format %%d: %d\n", A_int);
    printf("Character for ASCII value 98: %c\n", A_int);

    /* Assignment experiment: uncomment ONE line at a time.
       %f expects a double, but A_int is passed as an int: undefined behavior. */
    /* printf("%f\n", A_int); */

    return 0;
}
