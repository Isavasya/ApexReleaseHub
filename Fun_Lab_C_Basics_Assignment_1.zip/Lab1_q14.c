#include <stdio.h>

int main(void) {
    float length, breadth, base, height;

    printf("Enter rectangle length and breadth: ");
    if (scanf("%f %f", &length, &breadth) != 2) return 1;

    printf("Rectangle area (float): %.2f\n", length * breadth);
    printf("Rectangle perimeter (float): %.2f\n", 2.0f * (length + breadth));
    printf("Rectangle area stored as int: %d\n", (int)(length * breadth));

    printf("Enter triangle base and height: ");
    if (scanf("%f %f", &base, &height) != 2) return 1;
    printf("Triangle area: %.2f\n", 0.5f * base * height);
    return 0;
}
