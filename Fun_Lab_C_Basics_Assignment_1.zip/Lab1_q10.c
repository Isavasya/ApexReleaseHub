#include <stdio.h>

int main(void) {
    int A = 12;
    short int B = 12;
    long int C = 12L;
    long long int D = 12LL;

    printf("sizeof(int) = %zu bytes\n", sizeof(A));
    printf("sizeof(short int) = %zu bytes\n", sizeof(B));
    printf("sizeof(long int) = %zu bytes\n", sizeof(C));
    printf("sizeof(long long int) = %zu bytes\n", sizeof(D));

    /* "short short int" is not a valid C type declaration. */
    A = 2147483647;
    B = 32767;
    C = 2147483647L;
    D = 9223372036854775807LL;
    printf("Example values: %d %hd %ld %lld\n", A, B, C, D);

    /* Signed integer overflow is undefined behavior. Do not rely on a
       wrapped result; unsigned integer arithmetic has defined wraparound. */
    return 0;
}
