#include <stdio.h>

int main(void) {
    int var_int = 359033578;
    int another = 123456789;

    printf("Large integer as character: %c\n", var_int);
    printf("Another large integer as character: %c\n", another);

    /* %c converts the integer to an unsigned-char value for output.
       Values outside the ASCII range do not necessarily produce printable
       ASCII characters; the displayed result depends on the execution encoding. */
    return 0;
}
