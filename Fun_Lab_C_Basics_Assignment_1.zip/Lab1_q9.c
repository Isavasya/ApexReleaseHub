#include <stdio.h>

int main(void) {
    float A_float = 3.14159265358946984684054840969479323846f;
    double A_double = 3.14159265358946984684054840969479323846;

    printf("float:  %.21f\n", A_float);
    printf("double: %.21f\n", A_double);
    return 0;
}
