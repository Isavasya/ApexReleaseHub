#include <stdio.h>
#include <limits.h>
#include <float.h>

int main(void) {
    printf("=== INTEGER TYPES ===\n\n");
    printf("char:          %d to %d\n", CHAR_MIN, CHAR_MAX);
    printf("signed char:   %d to %d\n", SCHAR_MIN, SCHAR_MAX);
    printf("unsigned char: 0 to %u\n\n", UCHAR_MAX);
    printf("short:         %d to %d\n", SHRT_MIN, SHRT_MAX);
    printf("unsigned short: 0 to %u\n\n", USHRT_MAX);
    printf("int:           %d to %d\n", INT_MIN, INT_MAX);
    printf("unsigned int:  0 to %u\n\n", UINT_MAX);
    printf("long:          %ld to %ld\n", LONG_MIN, LONG_MAX);
    printf("unsigned long: 0 to %lu\n\n", ULONG_MAX);
    printf("long long:     %lld to %lld\n", LLONG_MIN, LLONG_MAX);
    printf("unsigned long long: 0 to %llu\n\n", ULLONG_MAX);

    printf("=== FLOATING POINT TYPES ===\n\n");
    printf("float:       %e to %e\n", FLT_MIN, FLT_MAX);
    printf("double:      %e to %e\n", DBL_MIN, DBL_MAX);
    printf("long double: %Le to %Le\n", LDBL_MIN, LDBL_MAX);
    printf("\nPrecision:\n");
    printf("float precision:       %d decimal digits\n", FLT_DIG);
    printf("double precision:      %d decimal digits\n", DBL_DIG);
    printf("long double precision: %d decimal digits\n", LDBL_DIG);
    return 0;
}
