#include <stdio.h>

int main(void) {
    printf("Hello, C programming!\n");       // a
    printf("Hello,\tC programming!\n");      // b: tab between comma and C
    printf("Hello,\n    C programming!\n");  // c
    printf("\"Hello, C programming!\"\n");   // d
    printf("\\t\n");                         // e: prints backslash and t
    printf("\\n\n");                         // f: prints backslash and n
    printf("\\\\\n");                        // g: prints one backslash
    printf("‘ ’\n");                          // h
    printf("‘hello’\n");                     // i
    return 0;
}
