Fun Lab with C Basics — Assignment 1
====================================

Contains one separate C source file for each of the 17 assignment questions:
Lab1_q1.c through Lab1_q17.c.

Compile one file at a time, for example:
    gcc -std=c11 -Wall -Wextra Lab1_q1.c -o Lab1_q1
    ./Lab1_q1

For Windows with GCC:
    gcc -std=c11 -Wall -Wextra Lab1_q1.c -o Lab1_q1.exe
    .\Lab1_q1.exe

Notes:
- Q4 and Q5 include commented-out format-mismatch experiments because mismatched
  printf format specifiers cause undefined behavior. Uncomment only for controlled
  experimentation; outputs are not reliable.
- Q14 requires rectangle length/breadth and triangle base/height as input.
- Some behavior explored by the assignment (large integer to %c, unknown escape
  sequence, multi-character character constant, out-of-range conversions) is
  implementation-dependent or undefined; output can vary by compiler/platform.
- Q11 uses portable size-format specifier %zu for sizeof results in Q10.
- Q13 demonstrates remainder for integers only because % is not valid for floats.
