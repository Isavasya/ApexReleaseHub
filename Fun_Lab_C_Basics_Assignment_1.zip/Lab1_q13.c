#include <stdio.h>

int main(void) {
    int i1 = 17, i2 = 5;
    float f1 = 17.5f, f2 = 5.0f;

    printf("Integer +: %d\n", i1 + i2);
    printf("Integer -: %d\n", i1 - i2);
    printf("Integer *: %d\n", i1 * i2);
    printf("Integer /: %d\n", i1 / i2);
    printf("Integer %%: %d\n", i1 % i2);

    printf("Float +: %.2f\n", f1 + f2);
    printf("Float -: %.2f\n", f1 - f2);
    printf("Float *: %.2f\n", f1 * f2);
    printf("Float /: %.2f\n", f1 / f2);
    /* The % remainder operator is defined only for integer operands. */

    printf("Integer + float: %.2f\n", i1 + f2);
    printf("Integer - float: %.2f\n", i1 - f2);
    printf("Integer * float: %.2f\n", i1 * f2);
    printf("Integer / float: %.2f\n", i1 / f2);
    return 0;
}
