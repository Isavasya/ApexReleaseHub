#include <stdio.h>

int main(void) {
    float a = 10.5;
    float b = 10.5f;
    long int x = 10;
    long int y = 10L;

    printf("a = %.2f\n", a);
    printf("b = %.2f\n", b);
    printf("x = %ld\n", x);
    printf("y = %ld\n", y);
    return 0;
}
