#include <stdio.h>

int main(void) {
    printf("hello\n");
    printf("hello\\0\n");
    printf("hello\\0\\0\n");
    printf("\\0hello\n");

    printf("Visible text before null: ");
    printf("hello\0world\n");

    /* A null character ends a C string when used as its terminator.
       Characters after the first \0 are not printed by %s/printf string output. */
    return 0;
}
