#include <stdio.h>

int main(void) {
    int x = 10;

    printf("Decimal: %d\n", x);
    printf("Octal: %o\n", x);
    printf("Hexadecimal: %x\n", x);

    printf("012 as decimal: %d\n", 012);
    printf("0xA as decimal: %d\n", 0xA);
    return 0;
}
