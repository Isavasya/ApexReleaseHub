#include <stdio.h>

int main(void) {
    float A_float = 3.1415f;

    printf("Correct format %%f: %.4f\n", A_float);

    /* Assignment experiment: uncomment ONE line at a time.
       These format specifiers do not match a float argument.
       The behavior is undefined by the C standard, so output is not reliable. */
    /* printf("%d\n", A_float); */
    /* printf("%c\n", A_float); */

    return 0;
}
