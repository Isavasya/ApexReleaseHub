#include <stdio.h>

int main(void) {
    printf(" * \n");
    /* The sequence \* is not a standard C escape sequence.
       This line may produce a compiler warning; common compilers
       print the asterisk and discard the backslash. */
    printf(" \\* \n");
    return 0;
}
