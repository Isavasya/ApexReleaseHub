#include <stdio.h>
#include <limits.h>

int main(void) {
    /* (a) The null character terminates the string for printf. */
    printf("Hello\0World\n");

    /* (b) Character arithmetic uses the character's integer value. */
    char c = 'A';
    printf("%c %d\n", c + 1, c + 1);

    /* (c) short is promoted to int before addition on typical C implementations. */
    short s = 32767;
    printf("%d\n", s + 1);

    /* (d) Chained assignment stores 5 in each variable. */
    int a, b, d;
    a = b = d = 5;
    printf("%d %d %d\n", a, b, d);
    d = 1;
    printf("%d\n", a);

    /* (e) Keep the assignment's x print and also print y to show the assignment. */
    int x = INT_MAX;
    printf("x = %d\n", x);
    long long large = (long long)INT_MAX + 1LL;
    printf("INT_MAX + 1 as long long = %lld\n", large);
    /* Assigning an out-of-range value to int is implementation-defined or
       may raise an implementation-defined signal; avoid relying on it. */

    /* (f) Multi-character constants such as 'AB' are implementation-defined.
       Their value is not portable. */
    printf("'A' as int = %d\n", 'A');
    printf("'AB' as int = %d\n", 'AB');
    printf("\"AB\" as string = %s\n", "AB");

    return 0;
}
