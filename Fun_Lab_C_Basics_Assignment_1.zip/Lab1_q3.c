#include <stdio.h>

int main(void) {
    printf("AB\bC\n");
    printf("123\b4\n");

    /* Try moving \b or placing it at the end:
       \b moves the output position one character backward.
       What becomes visible depends on the terminal/output device. */
    printf("ABC\b\n");
    printf("XYZ\b");
    return 0;
}
