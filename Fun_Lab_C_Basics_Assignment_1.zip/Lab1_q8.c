#include <stdio.h>

int main(void) {
    double A_double = 2345.34524354334933452454653;

    printf("Default: %f\n", A_double);
    printf("Four decimal places: %.4f\n", A_double);
    printf("Thirteen decimal places: %.13f\n", A_double);
    printf("Very high precision: %.50f\n", A_double);

    /* Extremely large precision requests can create very long output.
       The stored double has finite precision, so later digits are not
       additional information about the original decimal number. */
    return 0;
}
