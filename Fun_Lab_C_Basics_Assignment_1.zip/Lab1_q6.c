#include <stdio.h>

int main(void) {
    char A_char = 'b';
    int number = 38;
    char symbol = '&';
    char examples[] = {'A', '0', ' ', '\n'};

    printf("Character b with %%c: %c\n", A_char);
    printf("Character b with %%d: %d\n", A_char);
    printf("Integer 38 with %%c: %c\n", number);
    printf("Character & with %%d: %d\n", symbol);

    printf("'A' = %d\n", 'A');
    printf("'0' = %d\n", '0');
    printf("space = %d\n", ' ');
    printf("'\\n' = %d\n", '\n');

    (void)examples;
    return 0;
}
