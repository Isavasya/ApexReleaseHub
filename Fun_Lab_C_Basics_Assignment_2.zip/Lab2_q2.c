#include <stdio.h>

int main(void) {
    float f = 1234.5678f;
    short int s = -123;
    unsigned short int us = 65000;
    int i = 12345;
    unsigned int u = 4000000000U;
    long int li = 123456789L;
    long long int lli = 1234567890123LL;
    unsigned long long int ull = 123456789012345ULL;
    char word[] = "Hello C";

    printf("%%f = %f\n", f);
    printf("%%e = %e\n", f);
    printf("%%g = %g\n", f);
    printf("%%hd = %hd\n", s);
    printf("%%hu = %hu\n", us);
    printf("%%i = %i\n", i);
    printf("%%o = %o\n", i);
    printf("%%s = %s\n", word);
    printf("%%u = %u\n", u);
    printf("%%x = %x\n", i);
    printf("%%ld = %ld\n", li);
    printf("%%lld = %lld\n", lli);
    printf("%%llu = %llu\n", ull);

    /* %h alone is not a complete standard printf conversion specifier.
       For short integers, use %hd (signed) or %hu (unsigned). */
    return 0;
}
