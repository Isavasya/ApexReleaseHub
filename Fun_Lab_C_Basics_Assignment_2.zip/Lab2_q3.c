#include <stdio.h>

int main(void) {
    printf("Alert: \a\n");
    printf("Backspace: ABC\bD\n");
    printf("Form feed: before\fafter\n");
    printf("Carriage return: ABC\rXY\n");
    printf("Vertical tab: A\vB\n");
    printf("Question mark: \?\n");
    printf("Null character demonstration: ");
    printf("hello\0world\n");
    printf("Newline: first\nsecond\n");
    printf("Tab: left\tright\n");
    printf("Backspace at end: XYZ\b");
    return 0;
}
