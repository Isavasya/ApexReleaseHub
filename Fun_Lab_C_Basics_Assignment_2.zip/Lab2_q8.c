#include <stdio.h>

int main(void) {
    int x, y;
    int a, b, c;

    y = 5 + 3 * 2; printf("a) y = %d\n", y);
    y = (5 + 3) * 2; printf("b) y = %d\n", y);
    y = 10 + 20 / 5; printf("c) y = %d\n", y);
    y = 100 / 10 * 5; printf("d) y = %d\n", y);
    y = 17 % 3 + 2; printf("e) y = %d\n", y);
    y = -5 + 3; printf("f) y = %d\n", y);

    x = 5; y = ++x * 2; printf("g) x = %d, y = %d\n", x, y);
    x = 5; y = x++ * 2; printf("h) x = %d, y = %d\n", x, y);
    y = 5 + 3 > 7; printf("i) y = %d\n", y);
    x = 5; y = (x == 5); printf("j) y = %d\n", y);
    y = (5 > 2) && (3 > 4) || (10 > 2); printf("k) y = %d\n", y);

    a = 2; b = 3; y = ++a + b++ * 2; printf("l) y = %d, a = %d, b = %d\n", y, a, b);
    a = 5; b = 3; y = a + 2 > b + 4; printf("m) y = %d\n", y);
    a = 2; b = 3; c = 4; y = (a + (b * c) - 5) / 2; printf("n) y = %d\n", y);
    x = 6; y = x & 3 | 1; printf("o) y = %d\n", y);
    y = 5; y += 5 * 2; printf("p) y = %d\n", y);
    a = b = c = 5 + 2; printf("q) a = %d, b = %d, c = %d\n", a, b, c);
    a = 5; b = 4; y = a & b == 1; printf("r) y = %d\n", y);
    a = 18; b = 8; c = 5; y = a & b | c ^ a; printf("s) y = %d\n", y);

    x = 10; int yy = 2; y = ~(x & yy) | (x ^ yy); printf("t) y = %d\n", y);
    a = 18; b = 11; c = 5; y = (a & b) ^ (b | c) & ~(a ^ c); printf("u) y = %d\n", y);
    a = 6; b = 3; y = (a & b) ^ (a | b); printf("v) y = %d\n", y);
    a = 11; b = 4; y = (a & b) + (a ^ b) - (~b); printf("w) y = %d\n", y);
    a = 8; b = 3; y = ~(a | b) & (a ^ b); printf("x) y = %d\n", y);
    a = 5; b = 3; c = 2; y = a + b * c - (a + b) / c + b % c; printf("y) y = %d\n", y);

    return 0;
}
