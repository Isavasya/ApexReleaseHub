#include <stdio.h>
#include <string.h>

int main(void) {
    char A[] = "hello";
    char name[] = "Anand";

    printf("A = %s\n", A);
    printf("sizeof(A) = %zu bytes\n", sizeof(A));
    printf("strlen(A) = %zu characters\n", strlen(A));

    printf("name = %s\n", name);
    printf("sizeof(name) = %zu bytes\n", sizeof(name));
    printf("strlen(name) = %zu characters\n", strlen(name));

    /* sizeof includes the terminating '\0'; strlen does not. */
    return 0;
}
