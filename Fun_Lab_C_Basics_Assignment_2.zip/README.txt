Fun Lab with C Basics — Assignment 2
====================================

Files:
Lab2_q1.c through Lab2_q9.c
Lab2_q10a.c (simple/compound interest)
Lab2_q10b.c (restaurant menu and bill)
Lab2_q11.c through Lab2_q16.c

Compile one program at a time:
    gcc -std=c11 -Wall -Wextra Lab2_q1.c -o Lab2_q1
    ./Lab2_q1

For the compound-interest program on systems requiring libm:
    gcc -std=c11 -Wall -Wextra Lab2_q10a.c -o Lab2_q10a -lm
    ./Lab2_q10a

Notes:
- Q8 includes a portable executable interpretation of the expressions. The source sheet's
  items t, w, and x contain likely typographical/variable inconsistencies; the code uses
  sensible corrections and labels them in output. Specifically, t uses x=10 and y=2,
  w treats the missing operator in "(~b) (" as subtraction, and x uses a=8, b=3.
- Q12 intentionally includes the semicolon after if to demonstrate the bug; both blocks run.
- Q15 intentionally omits break to demonstrate fall-through. Q16 reverses case order and
  includes break for clear behavior.
- Q2 demonstrates valid standard printf specifiers. %h alone is not a complete conversion.
