#include <stdio.h>

int main(void) {
    int num = 2;

    printf("Value of num = %d\n", num);
    switch (num) {
        case 3:
            printf("Case 3 executed\n");
            break;
        case 2:
            printf("Case 2 executed\n");
            break;
        case 1:
            printf("Case 1 executed\n");
            break;
        default:
            printf("Default executed\n");
    }
    return 0;
}
