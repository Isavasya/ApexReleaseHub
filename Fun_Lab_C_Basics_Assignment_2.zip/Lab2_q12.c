#include <stdio.h>

int main(void) {
    int x = 5;

    /* With semicolons immediately after if conditions, the if controls an
       empty statement; the following blocks always execute. */
    if (x > 0);
    {
        printf("x is positive\n");
    }

    if (x < 0);
    {
        printf("x is negative\n");
    }

    /* Remove the semicolon after if to make each block conditional. */
    return 0;
}
