#include <stdio.h>

int main(void) {
    int choice;
    printf("Choose a classroom: 1 for A, 2 for B, 3 for C: ");
    if (scanf("%d", &choice) != 1) return 1;

    switch (choice) {
        case 1: printf("Classroom A\n"); break;
        case 2: printf("Classroom B\n"); break;
        case 3: printf("Classroom C\n"); break;
        default: printf("Invalid classroom choice\n");
    }

    /* C switch labels must be integer constant expressions.
       Strings, floating-point labels, and variable case labels are not allowed.
       Use if-else for ranges and more complex conditions. */
    return 0;
}
