#include <stdio.h>

int main(void) {
    const int group = 40;
    printf("Group size = %d\n", group);

    /* The following is intentionally commented out because it will not compile:
       group = 45;
       const objects cannot be modified after initialization. */
    return 0;
}
