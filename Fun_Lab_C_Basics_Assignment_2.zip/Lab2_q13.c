#include <stdio.h>

int main(void) {
    int i = 1;
    int j = 1;

    if (i == 1) {
        printf("i=1\n");
    } else if (j == 1) {
        printf("j=1 again\n");
    } else {
        printf("no printing\n");
    }

    return 0;
}
