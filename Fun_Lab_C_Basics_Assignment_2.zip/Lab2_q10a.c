#include <stdio.h>
#include <math.h>

int main(void) {
    int choice;
    double principal, rate, years, amount, interest;

    printf("1. Simple Interest\n2. Compound Interest\nChoose: ");
    if (scanf("%d", &choice) != 1) return 1;
    printf("Enter principal, annual rate (%%), and time in years: ");
    if (scanf("%lf %lf %lf", &principal, &rate, &years) != 3) return 1;

    if (principal < 0 || rate < 0 || years < 0) {
        printf("Inputs must be non-negative.\n");
        return 1;
    }

    if (choice == 1) {
        interest = principal * rate * years / 100.0;
        printf("Simple interest = %.2f\n", interest);
        printf("Total amount = %.2f\n", principal + interest);
    } else if (choice == 2) {
        amount = principal * pow(1.0 + rate / 100.0, years);
        interest = amount - principal;
        printf("Compound interest (annual compounding) = %.2f\n", interest);
        printf("Total amount = %.2f\n", amount);
    } else {
        printf("Invalid choice.\n");
    }
    return 0;
}
