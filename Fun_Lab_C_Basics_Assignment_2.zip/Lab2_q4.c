#include <stdio.h>

int main(void) {
    printf("sizeof(char) = %zu byte(s)\n", sizeof(char));
    printf("sizeof(short int) = %zu byte(s)\n", sizeof(short int));
    printf("sizeof(int) = %zu byte(s)\n", sizeof(int));
    printf("sizeof(unsigned int) = %zu byte(s)\n", sizeof(unsigned int));
    printf("sizeof(long int) = %zu byte(s)\n", sizeof(long int));
    printf("sizeof(long long int) = %zu byte(s)\n", sizeof(long long int));
    printf("sizeof(float) = %zu byte(s)\n", sizeof(float));
    printf("sizeof(double) = %zu byte(s)\n", sizeof(double));
    printf("sizeof(long double) = %zu byte(s)\n", sizeof(long double));
    return 0;
}
