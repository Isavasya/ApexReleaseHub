#include <stdio.h>

int main(void) {
    int a, b;
    printf("Enter two integers: ");
    if (scanf("%d %d", &a, &b) != 2) return 1;

    if (a > b) printf("%d is greater than %d\n", a, b);
    else if (a < b) printf("%d is less than %d\n", a, b);
    else printf("%d is equal to %d\n", a, b);

    return 0;
}
