#include <stdio.h>

int main(void) {
    int a = 6, b = 3;

    printf("6 & 3 = %d\n", a & b);
    printf("6 | 3 = %d\n", a | b);
    printf("6 ^ 3 = %d\n", a ^ b);

    printf("Binary view (6): 0110\n");
    printf("Binary view (3): 0011\n");
    printf("AND result:      0010 = 2\n");
    printf("OR result:       0111 = 7\n");
    printf("XOR result:      0101 = 5\n");
    return 0;
}
