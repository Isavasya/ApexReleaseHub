#include <stdio.h>

int main(void) {
    char c = 100;
    int i = c + 1;
    printf("char c = 100; c + 1 = %d\n", i);

    int a = 5;
    float b = 2.5f;
    float result = a + b;
    printf("a + b = %f\n", result);

    int x = 5, y = 2;
    printf("x / y with %%d = %d\n", x / y);
    float z = x / y;
    printf("float z = x / y = %f\n", z);
    float z2 = (float)x / y;
    printf("(float)x / y = %f\n", z2);

    float pi = 3.14159f;
    int truncated = (int)pi;
    printf("(int)pi = %d\n", truncated);

    double d = 3.1415;
    int n = 2;
    double sum = d + n;
    printf("d + n = %lf\n", sum);
    return 0;
}
