#include <stdio.h>

int main(void) {
    int i, j = 1;
    printf("i is uninitialized; j = %d\n", j);
    /* j is initialized to 1. i has an indeterminate value until assigned. */
    return 0;
}
