#include <stdio.h>

int main(void) {
    int choice, add_side = 0;
    double total = 0.0;
    char answer;

    printf("========== CAMPUS CAFE MENU ==========\n");
    printf("1. Paneer Curry       Rs 160\n");
    printf("2. Veg Fried Rice     Rs 120\n");
    printf("3. Chapati (2 pcs)    Rs  30\n");
    printf("4. Masala Dosa        Rs  90\n");
    printf("5. Veg Sandwich       Rs  80\n");
    printf("6. Gulab Jamun        Rs  40\n");
    printf("Choose one main item (1-6): ");

    if (scanf("%d", &choice) != 1) {
        printf("Invalid input.\n");
        return 1;
    }

    switch (choice) {
        case 1:
            total += 160;
            printf("Paneer curry selected. Allergy note: may contain dairy and nuts.\n");
            printf("Would you like rice (Rs 120) or chapati (Rs 30)? Enter R/C/N: ");
            scanf(" %c", &answer);
            if (answer == 'R' || answer == 'r') { total += 120; add_side = 1; }
            else if (answer == 'C' || answer == 'c') { total += 30; add_side = 1; }
            else if (answer != 'N' && answer != 'n') { printf("Invalid side choice; no side added.\n"); }
            break;
        case 2:
            total += 120;
            printf("Veg fried rice selected. Allergy note: may contain soy or sauces with gluten.\n");
            break;
        case 3:
            total += 30;
            printf("Chapati selected. Allergy note: contains wheat/gluten.\n");
            break;
        case 4:
            total += 90;
            printf("Masala dosa selected. Allergy note: may contain dairy; batter may be cross-contaminated.\n");
            break;
        case 5:
            total += 80;
            printf("Veg sandwich selected. Allergy note: contains wheat; may contain dairy.\n");
            break;
        case 6:
            total += 40;
            printf("Gulab jamun selected. Allergy note: contains dairy and wheat.\n");
            break;
        default:
            printf("Sorry, that item is not on the menu.\n");
            return 1;
    }

    printf("\n========== FINAL BILL ==========\n");
    printf("Main item price included. Side item %s.\n", add_side ? "added" : "not added");
    printf("Total: Rs %.2f\n", total);
    printf("Please inform staff about allergies; ingredients may vary.\n");
    return 0;
}
